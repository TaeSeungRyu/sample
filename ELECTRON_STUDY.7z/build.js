var electronInstaller = require('electron-winstaller');

// In this case, we can use relative paths
var settings = {
    // Specify the folder where the built app is located
    appDirectory: 'E:/ELECTRON_STUDY/dist/win-unpacked',
    // Specify the existing folder where 
    outputDirectory: 'E:/ELECTRON_STUDY/installer/',
    // The name of the Author of the app (the name of your company)
    authors: 'Our Code World Inc.',
    // The name of the executable of your built
    exe: 'E:/ELECTRON_STUDY/dist/win-unpacked/electron_study.exe'
};

resultPromise = electronInstaller.createWindowsInstaller(settings);
 
resultPromise.then(() => {
    console.log("The installers of your application were succesfully created !");
}, (e) => {
    console.log(`Well, sometimes you are not so lucky: ${e.message}`)
});