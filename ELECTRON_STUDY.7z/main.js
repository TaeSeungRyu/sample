
const { app, BrowserWindow } = require('electron');
const {Menu, Tray} = require('electron');

let tray;
//트레이 아이콘
function initTrayIconMenu(){
  tray = new Tray('E:/icon.png'); 
  //type 종류입니다 : 'normal', 'separator', 'submenu', 'checkbox', 'radio'
  const myMenu = Menu.buildFromTemplate([
    {label: '1번', type: 'normal', checked: true, click: ()=>{console.log('1번클릭!')} },  //checked는 기본선택입니다.
    {label: '2번', type: 'normal', click: ()=>{console.log('2번클릭!')}},
    {label: '3번', type: 'normal', click: ()=>{console.log('3번클릭!')}}
  ])
  tray.setToolTip('트레이 아이콘!')
  tray.setContextMenu(myMenu)
}

// 브라우저 창을 생성하는 함수
function createWindow () {  
  let win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true  //require같은 기능 사용 가능하도록
    }
  });
  win.loadFile('./html/index.html');
  initTrayIconMenu();
}

app.on('ready', createWindow);



/*
const { app, BrowserWindow } = require('electron');



function createWindow () {  // 브라우저 창을 생성
  let win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true  //require같은 기능 사용 가능하도록
    }
  });
  //브라우저창이 읽어 올 파일 위치
  win.loadFile('./html/index.html');
  //win.setMenu(null); //top 메뉴 세팅
}

//app.on('ready', createWindow);


//-------------- html과의 연동 부분 --------------

const sripts = require('./script.js');
const { ipcMain } = require('electron')
const rootPath = require('electron-root-path').rootPath;

sripts.init(rootPath);

//조회 요청시
ipcMain.on('select', (event, arg) => {
  sripts.select().then( arg=>{
    event.reply('reply', arg);  //결과 완료 후 보내는 방법
  }).catch((error)=>{
    event.reply('reply', error);  //에러
  });
});


//데이터 변경 요청시
ipcMain.on('alter', (event, param) => {
  if(param.type == 1){ //등록
    sripts.insert(param);
  }  else if(param.type == 2){ //수정
    sripts.update(param).then( arg=>{

    }).catch((error)=>{
  
    });
  } else {  //삭제
    sripts.delete(param).then( arg=>{

    }).catch((error)=>{

    });
  }
});





function handleSquirrelEvent(application) {
  if (process.argv.length === 1) {
      return false;
  }

  const ChildProcess = require('child_process');
  const path = require('path');

  const appFolder = path.resolve(process.execPath, '..');
  const rootAtomFolder = path.resolve(appFolder, '..');
  const updateDotExe = path.resolve(path.join(rootAtomFolder, 'test.exe'));
  const exeName = path.basename(process.execPath);

  const spawn = function(command, args) {
      let spawnedProcess, error;

      try {
          spawnedProcess = ChildProcess.spawn(command, args, {
              detached: true
          });
      } catch (error) {}

      return spawnedProcess;
  };

  const spawnUpdate = function(args) {
      return spawn(updateDotExe, args);
  };

  const squirrelEvent = process.argv[1];
  switch (squirrelEvent) {
      case '--squirrel-install':
      case '--squirrel-updated':
          // Optionally do things such as:
          // - Add your .exe to the PATH
          // - Write to the registry for things like file associations and
          //   explorer context menus

          // Install desktop and start menu shortcuts
          spawnUpdate(['--createShortcut', exeName]);

          setTimeout(application.quit, 1000);
          return true;

      case '--squirrel-uninstall':
          // Undo anything you did in the --squirrel-install and
          // --squirrel-updated handlers

          // Remove desktop and start menu shortcuts
          spawnUpdate(['--removeShortcut', exeName]);

          setTimeout(application.quit, 1000);
          return true;

      case '--squirrel-obsolete':
          // This is called on the outgoing version of your app before
          // we update to the new version - it's the opposite of
          // --squirrel-updated

          application.quit();
          return true;
  }
};*/